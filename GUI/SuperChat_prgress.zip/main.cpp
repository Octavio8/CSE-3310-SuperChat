#include <iostream>
#include "Controller.h"

using namespace std;

int main()
{
    //cout << "Hello world!" << endl;

    Controller boss;

    boss.run_the_show();

    return 0;
}
